import { useEffect, useState } from "react";
import axios from 'axios';
import { useParams } from "react-router-dom";

function App() {
  const params = useParams();
  // const [dataVal,setDataVal] = useState({})
  const [mind, setMind] = useState({})
  const [med, setMed] = useState([])
  const [lifestyle, setLifestyle] = useState([])
  const [ortho, setOrtho] = useState([])
  const [bodyAssess, setBodyAssess] = useState({})
  const [familyHistory,setFamilyHistory] = useState({})

  function mindVal(val) {
    let x = {}
    const mindOrder = ["FirstName", "LastName", "Gender", "Email", "BirthDate", "Country", "State", "City", "AddressLine1", "PostalCode", "MobilePhone", "EmergencyContactInfoName", "EmergencyContactInfoPhone", "EmergencyContactInfoRelationship", "ReferredBy", "SendPromotionalEmails", "SendAccountEmails", "SendScheduleEmails", "clientType"]
    mindOrder.forEach(key => {

      if (val[key]) {
        x[key] = val[key];
      }
    });
    setMind(x)
  }

  function commonVal(val) {
    // Convert the input object into an array of key-value pairs
    const data = Object.entries(val);

    // Filter the array to include only entries where the value is an array
    const updatedData = data
      .filter(([key, value]) => Array.isArray(value))
      .map(([key, value]) => ({ [key]: value }));
    return updatedData
  }
  
  const removeEmptyStringValues = (obj) => {
    Object.keys(obj).forEach((key) => {
      if (obj[key] === '') {
        delete obj[key];
      }
    });
    return obj;
  };


  useEffect(() => {
    // Define the async function to fetch data
    const fetchData = async () => {
      try {
        const url = `http://54.198.95.151:5000/client/${params.id}`;
        const response = await axios.get(url);
        mindVal(response?.data?.data?.mindBodyData)
        const medHis = commonVal(response?.data?.data?.parq?.medicalHistory)
        setMed(medHis)
        const lifeSt = commonVal(response?.data?.data?.parq?.lifestyle)
        setLifestyle(lifeSt)
        const orth = commonVal(response?.data?.data?.parq?.ortho)
        setOrtho(orth)
        const bodyAs = removeEmptyStringValues(response?.data?.data?.bodyAssessment)
        setBodyAssess(bodyAs)
        setFamilyHistory(response?.data?.data?.parq?.familyHistory)
        // setDataVal(response?.data?.data)
      } catch (err) {
      } finally {
      }
    };

    // Call the function
    fetchData();
  }, []);

  const data = [
    { name: "Heart", value: "Byepass,Surgery,Heart Attack" },
    { name: "Pacemaker", value: "Pacemaker,Implantable" },
    { name: "BP", value: "Beta Blocker,Angioplasty" },
    { name: "Heart", value: "Byepass,Surgery,Heart Attack" },
    { name: "Chest Pain", value: "Angina,Reflux" },
    { name: "Dizziness", value: "Dizziness,Fainting" },
  ]
  // const lifestyle = [
  //   { name: "Assessor Question", value: "Yes" },
  //   { name: "Are you or have you been a cigarette smoker?", value: "Formal" },
  //   { name: "Are you or have you been a e-cigarette?", value: "Medium" },
  //   { name: "Stress Level", value: "High" },
  //   { name: "Chest Pain", value: "Angina,Reflux" },
  //   { name: "Do you wake up feeling well rested?", value: "No" },
  // ]
  return (
    <div style={
      {
        display: "flex",
        flexDirection: "column",
        gap: "32px",
        paddingBottom: "32px"
      }
    }>
      <div
        style={
          {
            background: `url(https://app-development-resourcifi.s3.amazonaws.com/Uploads/1724931802190/back.png)`,
            height: "456px"
          }
        }>
        <div style={
          {
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "18px 60px 0px 60px",
          }
        }>
          <div style=
            {{
              fontFamily: '"Oswald", sans-serif',
              fontWeight: "600",
              color: "white",
              fontSize: "16px"
            }}>
            Summary Report
          </div>
          <div>
            <div>
              <img src={`https://app-development-resourcifi.s3.amazonaws.com/Uploads/1724931740479/gym.png`} alt="gym-guyz" />
            </div>
            <div>
              <img src={`https://app-development-resourcifi.s3.amazonaws.com/Uploads/1724931740448/txt.png`} alt="gym-txt" />
            </div>
          </div>
        </div>
        <div style={
          {
            display: "flex",
            justifyContent: "space-between",
            padding: "0px 60px 0px 60px",
          }
        }>
          <div style={
            {
              marginTop: "96px"
            }
          }>
            <div style=
              {{
                fontFamily: '"Oswald", sans-serif',
                fontWeight: "700",
                color: "white",
                fontSize: "24px"
              }}>
              A Comprehensive
            </div>
            <div style=
              {{
                fontFamily: '"Oswald", sans-serif',
                fontWeight: "700",
                color: "white",
                fontSize: "24px"
              }}>
              Physical Assessment Report
            </div>
            <div style={
              {
                borderTop: "2.82px solid #E4002B",
                marginTop: "11.3px"
              }
            }>

            </div>
            <div style={
              {
                display: "flex",
                gap: "32px",
                marginTop: "11.3px"
              }
            }>
              <div>
                <div style={
                  {
                    fontFamily: '"Oswald", sans-serif',
                    fontWeight: "400",
                    color: "white",
                    fontSize: "16px"
                  }
                }>
                  Assessment ID: #145668
                </div>
                <div style={
                  {
                    fontFamily: '"Oswald", sans-serif',
                    fontWeight: "500",
                    color: "white",
                    fontSize: "22px"
                  }
                }>
                  Brooklyn Simmons
                </div>
                <div style={
                  {
                    fontFamily: '"Oswald", sans-serif',
                    fontWeight: "400",
                    color: "white",
                    fontSize: "16px"
                  }
                }>
                  Male | 29 years
                </div>
              </div>
              <div style={
                {
                  borderLeft: "1px solid white"
                }
              }>
                |
              </div>
              <div>
                <div style={
                  {
                    fontFamily: '"Oswald", sans-serif',
                    fontWeight: "400",
                    color: "white",
                    fontSize: "16px"
                  }
                }>
                  Trainer ID: #145668
                </div>
                <div style={
                  {
                    fontFamily: '"Oswald", sans-serif',
                    fontWeight: "500",
                    color: "white",
                    fontSize: "22px"
                  }
                }>
                  Jenny Wilson
                </div>
                <div style={
                  {
                    fontFamily: '"Oswald", sans-serif',
                    fontWeight: "400",
                    color: "white",
                    fontSize: "16px"
                  }
                }>
                  Male | 29 years
                </div>
              </div>
              <div>
              </div>
            </div>
          </div>
          <div style={
            {
              marginTop: "104px",
              bottom: 0
            }
          }>
            <img src={'https://app-development-resourcifi.s3.amazonaws.com/Uploads/1724931802188/Rectangle%201.png'} alt="pic" style={{ width: "300px" }} />
          </div>
        </div>
      </div>
      <div style={
        {
          margin: "0px 60px"
        }
      }>
        <div style={
          {
            // height:"43px",
            backgroundColor: "#F4F5EF",
            padding: "8px 16px",
            fontFamily: '"Oswald", sans-serif',
            fontWeight: "500",
            color: "#000000",
            fontSize: "18px"

          }
        }>
          Mindbody Data Validation
        </div>
      </div>
      <div style={
        {
          margin: "0px 60px",
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: "10px",
          padding: "10px",
        }
      }>
        {Object.entries(mind).map(([key, value]) => (
          <div style={
            {
              display: "flex",
              flexDirection: "column",
              gap: "8px"
            }
          }>
            <div style={
              {
                fontFamily: '"Oswald", sans-serif',
                fontWeight: "400",
                color: "#000000",
                fontSize: "16px"
              }
            }>
              {key}
            </div>
            <div style={{
              fontFamily: 'Roboto, sans-serif',
              fontWeight: "400",
              color: "#666666",
              fontSize: "16px"
            }}>
              {value.toString()}
            </div>
          </div>
        ))}
      </div>

      <div style={
        {
          margin: "0px 60px"
        }
      }>
        <div style={
          {
            // height:"43px",
            backgroundColor: "#F4F5EF",
            padding: "8px 16px",
            fontFamily: '"Oswald", sans-serif',
            fontWeight: "500",
            color: "#000000",
            fontSize: "18px"

          }
        }>
          Medical History
        </div>
      </div>
      <div style={
        {
          alignItems: "center",
          padding: "16px",
          margin: "0px 60px",
          border: "1px solid #e3e3e3",
          borderRadius: "4px"
        }
      }>
        {med.map((item, index) => (
          <div key={index}>
            {Object.entries(item).map(([key, value], idx) => {
              const formattedKey = key.charAt(0).toUpperCase() + key.slice(1);
              return (
                <div key={idx} style={
                  {
                    display: "flex",
                    justifyContent: "space-between",
                    borderBottom: "1px solid #e3e3e3",
                    padding: "16px 0px"
                  }
                }>
                  <div style={
                    {
                      fontFamily: 'Roboto, sans-serif',
                      fontWeight: "400",
                      color: "#000000",
                      fontSize: "16px"
                    }
                  }>
                    {formattedKey}
                  </div>

                  <div style={
                    {
                      fontFamily: 'Roboto, sans-serif',
                      fontWeight: "400",
                      color: "#666666",
                      fontSize: "16px"
                    }
                  }>
                    {value.join(", ")}
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
      <div style={
        {
          margin: "0px 60px"
        }
      }>
        <div style={
          {
            // height:"43px",
            backgroundColor: "#F4F5EF",
            padding: "8px 16px",
            fontFamily: '"Oswald", sans-serif',
            fontWeight: "500",
            color: "#000000",
            fontSize: "18px"

          }
        }>
          Body Assessment
        </div>
      </div>
      <div style={
        {
          alignItems: "center",
          padding: "16px",
          margin: "0px 60px",
          border: "1px solid #e3e3e3",
          borderRadius: "4px"
        }
      }>
        {Object.entries(bodyAssess).map(([key, value]) => (
          
          <div >
            <div  style={
              {
                display: "flex",
                justifyContent: "space-between",
                borderBottom: "1px solid #e3e3e3",
                padding: "16px 0px"
              }
            }>
              <div style={
                {
                  fontFamily: 'Roboto, sans-serif',
                  fontWeight: "400",
                  color: "#000000",
                  fontSize: "16px"
                }
              }>
                {key.charAt(0).toUpperCase() + key.slice(1)}
              </div>

              <div style={
                {
                  fontFamily: 'Roboto, sans-serif',
                  fontWeight: "400",
                  color: "#666666",
                  fontSize: "16px"
                }
              }>
                {value}
              </div>
            </div>
          </div>
        ))}
      </div>
      <div style={
        {
          margin: "0px 60px"
        }
      }>
        <div style={
          {
            // height:"43px",
            backgroundColor: "#F4F5EF",
            padding: "8px 16px",
            fontFamily: '"Oswald", sans-serif',
            fontWeight: "500",
            color: "#000000",
            fontSize: "18px"

          }
        }>
          Lifestyle
        </div>
      </div>
      <div style={
        {
          alignItems: "center",
          padding: "16px",
          margin: "0px 60px",
          border: "1px solid #e3e3e3",
          borderRadius: "4px"
        }
      }>
        {lifestyle.map((item, index) => (
          <div key={index}>
            {Object.entries(item).map(([key, value], idx) => {
              const formattedKey = key.charAt(0).toUpperCase() + key.slice(1);
              return (
                <div key={idx} style={
                  {
                    display: "flex",
                    justifyContent: "space-between",
                    borderBottom: "1px solid #e3e3e3",
                    padding: "16px 0px"
                  }
                }>
                  <div style={
                    {
                      fontFamily: 'Roboto, sans-serif',
                      fontWeight: "400",
                      color: "#000000",
                      fontSize: "16px"
                    }
                  }>
                    {formattedKey}
                  </div>

                  <div style={
                    {
                      fontFamily: 'Roboto, sans-serif',
                      fontWeight: "400",
                      color: "#666666",
                      fontSize: "16px"
                    }
                  }>
                    {value.join(", ")}
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
      <div style={
        {
          margin: "0px 60px"
        }
      }>
        <div style={
          {
            // height:"43px",
            backgroundColor: "#F4F5EF",
            padding: "8px 16px",
            fontFamily: '"Oswald", sans-serif',
            fontWeight: "500",
            color: "#000000",
            fontSize: "18px"

          }
        }>
          Family History
        </div>
      </div>
      <div style={
        {
          alignItems: "center",
          padding: "16px",
          margin: "0px 60px",
          border: "1px solid #e3e3e3",
          borderRadius: "4px"
        }
      }>
        {Object.entries(familyHistory).map(([key, value]) => (
          
          <div >
            <div  style={
              {
                display: "flex",
                justifyContent: "space-between",
                borderBottom: "1px solid #e3e3e3",
                padding: "16px 0px"
              }
            }>
              <div style={
                {
                  fontFamily: 'Roboto, sans-serif',
                  fontWeight: "400",
                  color: "#000000",
                  fontSize: "16px"
                }
              }>
                {key.charAt(0).toUpperCase() + key.slice(1)}
              </div>

              <div style={
                {
                  fontFamily: 'Roboto, sans-serif',
                  fontWeight: "400",
                  color: "#666666",
                  fontSize: "16px"
                }
              }>
                {value.toString()}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div style={
        {
          margin: "0px 60px"
        }
      }>
        <div style={
          {
            // height:"43px",
            backgroundColor: "#F4F5EF",
            padding: "8px 16px",
            fontFamily: '"Oswald", sans-serif',
            fontWeight: "500",
            color: "#000000",
            fontSize: "18px"

          }
        }>
          Ortho
        </div>
      </div>
      <div style={
        {
          alignItems: "center",
          padding: "16px",
          margin: "0px 60px",
          border: "1px solid #e3e3e3",
          borderRadius: "4px"
        }
      }>
        {ortho.map((item, index) => (
          <div key={index}>
            {Object.entries(item).map(([key, value], idx) => {
              const formattedKey = key.charAt(0).toUpperCase() + key.slice(1);
              return (
                <div key={idx} style={
                  {
                    display: "flex",
                    justifyContent: "space-between",
                    borderBottom: "1px solid #e3e3e3",
                    padding: "16px 0px"
                  }
                }>
                  <div style={
                    {
                      fontFamily: 'Roboto, sans-serif',
                      fontWeight: "400",
                      color: "#000000",
                      fontSize: "16px"
                    }
                  }>
                    {formattedKey}
                  </div>

                  <div style={
                    {
                      fontFamily: 'Roboto, sans-serif',
                      fontWeight: "400",
                      color: "#666666",
                      fontSize: "16px"
                    }
                  }>
                    {value.join(", ")}
                  </div>
                </div>
              )
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
